package com.abureda.batterywidget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;

/** خدمة خفيفة بتسمع لتغيّر البطارية وبتحدّث الودجت فوراً. */
public class BatteryService extends Service {

    private static final String CHANNEL = "battery_widget";
    private static final int NOTIF_ID = 7;
    private int lastLevel = -1;
    private int lastCharging = -1;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context ctx, Intent i) {
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int level = (l >= 0 && s > 0) ? Math.round(l * 100f / s) : 0;
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int ch = (st == BatteryManager.BATTERY_STATUS_CHARGING
                    || st == BatteryManager.BATTERY_STATUS_FULL) ? 1 : 0;
            if (level != lastLevel || ch != lastCharging) {
                lastLevel = level;
                lastCharging = ch;
                BatteryWidgetProvider.updateAll(ctx);
            }
        }
    };

    public static void start(Context ctx) {
        try {
            Intent i = new Intent(ctx, BatteryService.class);
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i);
            else ctx.startService(i);
        } catch (Exception ignored) {
            // أندرويد 12+ ممكن يمنع التشغيل من الخلفية؛ بيشتغل لما تفتح التطبيق
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        startForeground(NOTIF_ID, buildNotification());
        registerReceiver(receiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        BatteryWidgetProvider.updateAll(this);
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(receiver); } catch (Exception ignored) {}
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL,
                    "تحديث ودجت البطارية", NotificationManager.IMPORTANCE_MIN);
            ch.setShowBadge(false);
            ch.setSound(null, null);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this).setPriority(Notification.PRIORITY_MIN);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("ودجت البطارية شغّال")
                .setContentIntent(pi)
                .setOngoing(true)
                .setShowWhen(false)
                .build();
    }
}

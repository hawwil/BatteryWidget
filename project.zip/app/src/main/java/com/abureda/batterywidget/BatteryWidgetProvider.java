package com.abureda.batterywidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class BatteryWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
        updateAll(ctx);
        BatteryService.start(ctx);
    }

    @Override
    public void onEnabled(Context ctx) {
        BatteryService.start(ctx);
    }

    @Override
    public void onDisabled(Context ctx) {
        ctx.stopService(new Intent(ctx, BatteryService.class));
    }

    /** يحدّث كل الودجات الموجودة على الشاشة. */
    public static void updateAll(Context ctx) {
        AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
        int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, BatteryWidgetProvider.class));
        if (ids == null || ids.length == 0) return;

        int[] b = BatteryRenderer.readBattery(ctx);
        RemoteViews rv = new RemoteViews(ctx.getPackageName(), R.layout.widget_battery);
        rv.setImageViewBitmap(R.id.battery_circle, BatteryRenderer.draw(b[0], b[1] == 1));

        Intent open = new Intent(ctx, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        rv.setOnClickPendingIntent(R.id.widget_root, pi);

        mgr.updateAppWidget(ids, rv);
    }

    public static boolean hasWidgets(Context ctx) {
        int[] ids = AppWidgetManager.getInstance(ctx)
                .getAppWidgetIds(new ComponentName(ctx, BatteryWidgetProvider.class));
        return ids != null && ids.length > 0;
    }
}

package com.abureda.batterywidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (BatteryWidgetProvider.hasWidgets(ctx)) {
            BatteryService.start(ctx);
            BatteryWidgetProvider.updateAll(ctx);
        }
    }
}

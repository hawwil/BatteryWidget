package com.abureda.batterywidget;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.BatteryManager;

/** يرسم دائرة البطارية كصورة. */
public final class BatteryRenderer {

    private static final int SIZE = 420;

    private BatteryRenderer() {}

    /** نسبة البطارية الحالية وحالة الشحن. */
    public static int[] readBattery(Context ctx) {
        Intent i = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = 0;
        boolean charging = false;
        if (i != null) {
            int l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (l >= 0 && s > 0) level = Math.round(l * 100f / s);
            int st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            charging = st == BatteryManager.BATTERY_STATUS_CHARGING
                    || st == BatteryManager.BATTERY_STATUS_FULL;
        }
        return new int[]{level, charging ? 1 : 0};
    }

    /** اللون حسب النسبة. */
    public static int colorFor(int level) {
        if (level >= 60) return Color.parseColor("#2ECC71"); // أخضر
        if (level >= 30) return Color.parseColor("#F4C430"); // أصفر
        if (level >= 15) return Color.parseColor("#FF8C1A"); // برتقالي
        return Color.parseColor("#FF4D4D");                  // أحمر
    }

    public static Bitmap draw(int level, boolean charging) {
        Bitmap bmp = Bitmap.createBitmap(SIZE, SIZE, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        float cx = SIZE / 2f, cy = SIZE / 2f;
        int color = colorFor(level);

        // خلفية داكنة عشان الدائرة تبين على أي خلفية
        Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        bg.setColor(Color.parseColor("#E6141A20"));
        c.drawCircle(cx, cy, SIZE / 2f - 2, bg);

        // المسار الرمادي
        float stroke = SIZE * 0.085f;
        float r = SIZE / 2f - stroke / 2f - SIZE * 0.06f;
        RectF oval = new RectF(cx - r, cy - r, cx + r, cy + r);
        Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeWidth(stroke);
        track.setColor(Color.parseColor("#2E3640"));
        c.drawArc(oval, 0, 360, false, track);

        // القوس الملون
        Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeWidth(stroke);
        arc.setStrokeCap(Paint.Cap.ROUND);
        arc.setColor(color);
        float sweep = Math.max(level, 1) * 3.6f;
        c.drawArc(oval, -90, sweep, false, arc);

        // الرقم
        Typeface bold = Typeface.create("sans-serif", Typeface.BOLD);
        Paint num = new Paint(Paint.ANTI_ALIAS_FLAG);
        num.setColor(Color.WHITE);
        num.setTypeface(bold);
        num.setTextSize(level == 100 ? SIZE * 0.27f : SIZE * 0.33f);

        Paint pct = new Paint(Paint.ANTI_ALIAS_FLAG);
        pct.setColor(Color.parseColor("#C8D0D8"));
        pct.setTypeface(bold);
        pct.setTextSize(num.getTextSize() * 0.45f);

        String n = String.valueOf(level);
        float nw = num.measureText(n);
        float pw = pct.measureText("%");
        float total = nw + pw + SIZE * 0.01f;
        float startX = cx - total / 2f;
        Paint.FontMetrics fm = num.getFontMetrics();
        float baseY = cy - (fm.ascent + fm.descent) / 2f + (charging ? SIZE * 0.04f : 0);
        c.drawText(n, startX, baseY, num);
        c.drawText("%", startX + nw + SIZE * 0.01f, baseY, pct);

        // صاعقة الشحن
        if (charging) {
            float s = SIZE * 0.075f;
            float bx = cx, by = baseY + fm.ascent - s * 0.9f;
            Path bolt = new Path();
            bolt.moveTo(bx + s * 0.20f, by - s);
            bolt.lineTo(bx - s * 0.55f, by + s * 0.15f);
            bolt.lineTo(bx - s * 0.05f, by + s * 0.15f);
            bolt.lineTo(bx - s * 0.20f, by + s);
            bolt.lineTo(bx + s * 0.55f, by - s * 0.15f);
            bolt.lineTo(bx + s * 0.05f, by - s * 0.15f);
            bolt.close();
            Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG);
            bp.setColor(color);
            c.drawPath(bolt, bp);
        }
        return bmp;
    }
}

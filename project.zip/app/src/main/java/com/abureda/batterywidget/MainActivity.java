package com.abureda.batterywidget;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {

    private ImageView preview;

    private final BroadcastReceiver live = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) { refresh(); }
    };

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.parseColor("#0E1216"));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#0E1216"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = dp(24);
        root.setPadding(p, dp(40), p, p);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = text("بطاريتي", 28, Color.WHITE, true);
        root.addView(title);

        preview = new ImageView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(180), dp(180));
        lp.setMargins(0, dp(24), 0, dp(24));
        root.addView(preview, lp);

        TextView steps = text(
                "عشان تحط الودجت:\n"
                + "١. اضغط ضغطة مطوّلة على مكان فاضي بالشاشة الرئيسية\n"
                + "٢. اختار «الأدوات» أو «Widgets»\n"
                + "٣. دوّر على «بطاريتي» وحط «دائرة البطارية»\n\n"
                + "عشان يضل يتحدّث على الردمي، اضغط الزرين تحت:",
                16, Color.parseColor("#C8D0D8"), false);
        steps.setLineSpacing(0, 1.3f);
        root.addView(steps);

        root.addView(button("تفعيل التشغيل التلقائي", v -> openAutostart()));
        root.addView(button("البطارية: بلا قيود", v -> openBatterySettings()));

        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        BatteryService.start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(live, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        refresh();
        BatteryWidgetProvider.updateAll(this);
    }

    @Override
    protected void onPause() {
        try { unregisterReceiver(live); } catch (Exception ignored) {}
        super.onPause();
    }

    private void refresh() {
        int[] b = BatteryRenderer.readBattery(this);
        preview.setImageBitmap(BatteryRenderer.draw(b[0], b[1] == 1));
    }

    private void openAutostart() {
        Intent i = new Intent();
        i.setComponent(new ComponentName("com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"));
        try { startActivity(i); } catch (Exception e) { openAppDetails(); }
    }

    private void openBatterySettings() {
        Intent i = new Intent("miui.intent.action.HIDDEN_APPS_CONFIG_ACTIVITY");
        i.putExtra("package_name", getPackageName());
        i.putExtra("package_label", getString(R.string.app_name));
        try { startActivity(i); return; } catch (Exception ignored) {}
        try {
            Intent r = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            r.setData(Uri.parse("package:" + getPackageName()));
            startActivity(r);
        } catch (Exception e) { openAppDetails(); }
    }

    private void openAppDetails() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.setData(Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.parseColor("#0E1216"));
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#2ECC71"));
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        lp.setMargins(0, dp(14), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}

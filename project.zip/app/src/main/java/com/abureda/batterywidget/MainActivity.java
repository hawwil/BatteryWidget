package com.abureda.batterywidget;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextPaint;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ReplacementSpan;

public class MainActivity extends Activity {

    private ImageView preview;

    private final BroadcastReceiver live = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) { refresh(); }
    };

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(Color.parseColor("#0E1216"));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.parseColor("#0E1216"));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = dp(24);
        root.setPadding(p, dp(40), p, p);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        TextView title = text("بطاريتي", 28, Color.WHITE, true);
        root.addView(title);

        preview = new ImageView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(180), dp(180));
        lp.setMargins(0, dp(24), 0, dp(24));
        root.addView(preview, lp);

        TextView steps = text(
                "عشان تحط الودجت:\n"
                + "١. اضغط ضغطة مطوّلة على مكان فاضي بالشاشة الرئيسية\n"
                + "٢. اختار «الأدوات» أو «Widgets»\n"
                + "٣. دوّر على «بطاريتي» وحط «دائرة البطارية»\n\n"
                + "عشان يضل يتحدّث على الردمي، اضغط الزرين تحت:",
                16, Color.parseColor("#C8D0D8"), false);
        steps.setLineSpacing(0, 1.3f);
        root.addView(steps);

        root.addView(button("تفعيل التشغيل التلقائي", v -> openAutostart()));
        root.addView(button("البطارية: بلا قيود", v -> openBatterySettings()));

        root.addView(footer());

        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        BatteryService.start(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(live, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        refresh();
        BatteryWidgetProvider.updateAll(this);
    }

    @Override
    protected void onPause() {
        try { unregisterReceiver(live); } catch (Exception ignored) {}
        super.onPause();
    }

    private void refresh() {
        int[] b = BatteryRenderer.readBattery(this);
        preview.setImageBitmap(BatteryRenderer.draw(b[0], b[1] == 1));
    }

    private void openAutostart() {
        Intent i = new Intent();
        i.setComponent(new ComponentName("com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"));
        try { startActivity(i); } catch (Exception e) { openAppDetails(); }
    }

    private void openBatterySettings() {
        Intent i = new Intent("miui.intent.action.HIDDEN_APPS_CONFIG_ACTIVITY");
        i.putExtra("package_name", getPackageName());
        i.putExtra("package_label", getString(R.string.app_name));
        try { startActivity(i); return; } catch (Exception ignored) {}
        try {
            Intent r = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            r.setData(Uri.parse("package:" + getPackageName()));
            startActivity(r);
        } catch (Exception e) { openAppDetails(); }
    }

    private void openAppDetails() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.setData(Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    /** حقوق الملكية: تم التطوير من NEXA للخدمات الرقمية */
    private View footer() {
        int grey = Color.parseColor("#9AA3AC");
        int gold = Color.parseColor("#D9A83F");
        Typeface bold = Typeface.create("sans-serif", Typeface.BOLD);

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        blp.setMargins(0, dp(48), 0, dp(8));
        box.setLayoutParams(blp);

        // السطر الأول: نص واحد، وكلمة NEXA عريضة وتحتها خط ذهبي وبتفتح الانستغرام
        String full = "تم التطوير من NEXA للخدمات الرقمية";
        int i0 = full.indexOf("NEXA"), i1 = i0 + 4;
        SpannableString sp = new SpannableString(full);
        sp.setSpan(new BrandSpan(Color.WHITE, gold, bold, dp(3), dp(5)),
                i0, i1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new ClickableSpan() {
            @Override public void onClick(View w) { openInstagram(); }
            @Override public void updateDrawState(TextPaint tp) { }
        }, i0, i1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView line1 = new TextView(this);
        line1.setText(sp);
        line1.setTextSize(15);
        line1.setTextColor(grey);
        line1.setGravity(Gravity.CENTER);
        line1.setTextDirection(View.TEXT_DIRECTION_RTL);
        line1.setMovementMethod(LinkMovementMethod.getInstance());
        line1.setHighlightColor(Color.TRANSPARENT);
        box.addView(line1, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        // السطر الثاني
        TextView rights = small("© NEXA 2026 · جميع الحقوق محفوظة", 13, grey);
        rights.setTextDirection(View.TEXT_DIRECTION_RTL);
        rights.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlp.setMargins(0, dp(10), 0, 0);
        box.addView(rights, rlp);

        // رقم النسخة
        String ver = "1.2";
        try {
            ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {}
        TextView v = small("v" + ver, 13, Color.parseColor("#6B747D"));
        LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        vlp.setMargins(0, dp(10), 0, 0);
        box.addView(v, vlp);

        return box;
    }

    /** يفتح صفحة NEXA على انستغرام (بالتطبيق إذا موجود، وإلا بالمتصفح). */
    private void openInstagram() {
        Uri u = Uri.parse("https://www.instagram.com/nexa.ryx/");
        Intent app = new Intent(Intent.ACTION_VIEW, u).setPackage("com.instagram.android");
        try { startActivity(app); }
        catch (Exception e) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
        }
    }

    private TextView small(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.START);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        t.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTextColor(Color.parseColor("#0E1216"));
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.parseColor("#2ECC71"));
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
        lp.setMargins(0, dp(14), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    /** يرسم NEXA بخط عريض أبيض وتحتها خط ذهبي. */
    static class BrandSpan extends ReplacementSpan {
        private final int textColor, lineColor, lineH, gap;
        private final Typeface face;
        BrandSpan(int textColor, int lineColor, Typeface face, int lineH, int gap) {
            this.textColor = textColor; this.lineColor = lineColor;
            this.face = face; this.lineH = lineH; this.gap = gap;
        }
        private Paint styled(Paint p) {
            Paint q = new Paint(p);
            q.setTypeface(face);
            q.setTextSize(p.getTextSize() * 1.15f);
            q.setLetterSpacing(0.06f);
            return q;
        }
        @Override
        public int getSize(Paint p, CharSequence t, int s, int e, Paint.FontMetricsInt fm) {
            Paint q = styled(p);
            if (fm != null) {
                Paint.FontMetricsInt m = q.getFontMetricsInt();
                fm.ascent = m.ascent; fm.top = m.top;
                // نكبّر أسفل السطر عشان الخط الذهبي ما ينقص
                int under = Math.round(gap * 1.4f) + lineH + 2;
                fm.descent = Math.max(m.descent, under);
                fm.bottom = Math.max(m.bottom, under);
            }
            return Math.round(q.measureText(t, s, e)) + gap * 2;
        }
        @Override
        public void draw(Canvas c, CharSequence t, int s, int e, float x, int top, int y,
                         int bottom, Paint p) {
            Paint q = styled(p);
            q.setColor(textColor);
            float w = q.measureText(t, s, e);
            c.drawText(t, s, e, x + gap, y, q);
            Paint l = new Paint(Paint.ANTI_ALIAS_FLAG);
            l.setColor(lineColor);
            float ly = y + gap * 1.4f;
            c.drawRect(x + gap * 0.4f, ly, x + gap * 1.6f + w, ly + lineH, l);
        }
    }
}
